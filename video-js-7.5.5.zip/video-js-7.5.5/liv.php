<!DOCTYPE html>
<head>
<title>Test Video.js</title>
<link href="video-js.min.css" rel="stylesheet">
<script src="video.min.js"></script>
</head>
<body>
<div id="testdiv"></div>
<video id=example-video class="video-js vjs-default-skin" width=960 height=540 class="video-js vjs-default-skin" controls data-setup='{"fluid": true}'>
  <source
     src="https://3e46f9f3de79c4d4.mediapackage.ap-south-1.amazonaws.com/out/v1/6517f54c5132474d832875a88dadfa9f/index.m3u8"
     type="application/x-mpegURL">
</video>
<script src="video.js"></script>
<script src="videojs.hls.min.js"></script>
<script>
var player = videojs('example-video');
player.play();
</script>
</body>
</html>